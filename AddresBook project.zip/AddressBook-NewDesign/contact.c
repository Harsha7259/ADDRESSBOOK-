#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
#include <ctype.h>


void initialize(AddressBook *addressBook)
 {  
	 // collecting as pointer
    addressBook->contactCount = 0;
    populateAddressBook(addressBook);
    
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}


// 	//STEP1: Fetch one by one character till null character
// 	#include <ctype.h>  // Needed for isalpha()

int name_validate(char *name)
{
	#include <ctype.h>  // Needed for isalpha()
    //STEP1: Fetch one by one character till null character

    if (name[0] == '\0')
    {
        return 1; // invalid (empty string)
    }

    // STEP 2: Fetch one by one character till null character
    int i = 0;
    while (name[i] != '\0')
    {
        if (name[i] != ' ')
        {
            if (!isalpha(name[i]))
            {
                return 1; // invalid
            }
        }
        i++;
    }
    return 0; // valid
}

int unique_name(char *name,AddressBook *addressBook) 
{
    for (int i = 0; i < addressBook->contactCount; i++) 
	{
        if (strcmp(addressBook->contacts[i].name, name) == 0)
		{
            return 1;  // Phone number is not unique
        }
    }
	return 0;
}




	//STEP2: Check the character is alpahebet or not
	//Yes-> Move to next character, NO -> Stop the process


// Function to validate mobile number

int phone_validate(char *phone) 
{
    if (strlen(phone) != 10)
	 {
        return 1;  // Invalid length
    }

    for (int i = 0; i < 10; i++)
	 {
        if (!isdigit(phone[i]))
		 {
            return 1;  // Non-digit found
        }
    }
    return 0;  // Valid phone number
}

int unique_phone(char *phone,AddressBook *addressBook) 
{
    for (int i = 0; i < addressBook->contactCount; i++) 
	{
        if (strcmp(addressBook->contacts[i].phone, phone) == 0)
		{
            return 1;  // Phone number is not unique
        }
    }
	return 0;
}
   

int email_validate(char* email)
{
	#include <string.h> // Required for strlen() and strcmp()
    int email_len = strlen(email);
    int domain_len = 10; // Length of "@gmail.com" that is 10

    if (email_len < domain_len) 
    {
        return 1; // Invalid email (too short)
    }

    // Compare the last 10 characters of the email with "@gmail.com"

    if (strcmp(email + email_len - domain_len, "@gmail.com") == 0)
    {
        return 0; // Valid email
    }

    return 1; // Invalid email
}

int unique_email(char *email,AddressBook *addressBook) 
{
    for (int i = 0; i < addressBook->contactCount; i++) 
	{
        if (strcmp(addressBook->contacts[i].email, email) == 0)
		{
            return 1;  // Phone number is not unique
        }
    }
	return 0;
}


void createContact(AddressBook *addressBook)
{
	char name[50],phone[20],email[50];

   //STEP1: Read a name from user
	printf("Enter the name: ");
	scanf(" %[^\n]", name);
	

    //STEP2: Validate the name -> Alphabets

	while(name_validate(name) == 1)
	{
		printf("INFO: Name validation not done, Please enter valid name...\n");
		printf("Enter the name: ");
		scanf(" %[^\n]", name);

	}	
	while (unique_name(name,addressBook) == 1)
	{
		printf("INFO: Name already exists, Please enter valid name...\n");
		printf("Enter the name: ");
		scanf(" %[^\n]", name);
		//True -> Goto STEP3, False -> print error, Goto STEP1
	}


	//STEP3: Read a mobile number from user
	// printf("Enter the mobile number should be 10 digits:");
	// scanf(" %[^\n]",phone);

	printf("Enter the mobile number:");
	scanf(" %[^\n]", phone);

	while(phone_validate(phone)==1)
	{
		printf("INFO: phone validation not done, Please enter valid number...\n");
		printf("Enter the number: ");
		scanf(" %[^\n]", phone);
	}

	//STEP4: Validate the mobile number -> Digit & 10 Digits & unique
	//True -> Goto STEP5, False -> print error, Goto STEP3

	while (unique_phone(phone,addressBook) == 1)
	{
		printf("INFO: phone number already exists, Please enter valid number...\n");
		printf("Enter the phone: ");
		scanf(" %[^\n]", phone);
		//True -> Goto STEP3, False -> print error, Goto STEP1
	}


	//STEP6: Validate the email_ID -> @gmail.com & unique
	//True -> Goto STEP7, False -> print error, Goto STEP5

	printf("Enter the email:");
	scanf(" %[^\n]", email);

	while(email_validate(email)==1)
	{
		printf("INFO: email validation not done, Please enter valid email...\n");
		printf("Enter the email: ");
		scanf(" %[^\n]", email);

	}

	while (unique_email(email,addressBook) == 1)
	{
		printf("INFO: email already exists, Please enter valid email...\n");
		printf("Enter the email: ");
		scanf(" %[^\n]", email);
		//True -> Goto STEP3, False -> print error, Goto STEP1
	}
	
	strcpy(addressBook->contacts[addressBook->contactCount].name,name);
	strcpy(addressBook->contacts[addressBook->contactCount].phone,phone);
	strcpy(addressBook->contacts[addressBook->contactCount].email,email);
	addressBook->contactCount++;
	printf("...contact successfully created...\n");
}
	




void searchContact(AddressBook *addressBook) //over
{
	
	/* Define the logic for search */
	//STEP1: Print the menu Based on what searching
	//STEP2: Choose the menu

	int choice;

	printf("choose any one details\n1.Name\n2.Mobilenumber\n3.Email\n4.Exit\n");
	printf("Enter the choice:");
	scanf("%d",&choice);

    
	//1 -> Name
	//Read the name
	//Search the extered name is present in the database or not
	//Yes -> Print the details about that contact, NO -> Print error, Goto STEP1.

	//2 -> Mobile_no
	//Read the mobile_no
	//Search the extered mobile_no is present in the database or not
	//Yes -> Print the details about that contact, NO -> Print error, Goto STEP1.

	//3 -> Email_id
	//Read the mail_id
	//Search the extered mail_id is present in the database or not
	//Yes -> Print the details about that contact, NO -> Print error, Goto STEP1.
	
     int found1=0,found2=0,found3=0;

	 switch(choice)
	 {
		
		case 1:
		char search_name[20];
		printf("Enter the name to search :");
		scanf(" %[^\n]",search_name);

		  for (int i = 0; i < addressBook->contactCount; i++) 
		  {
                if (strcmp(addressBook->contacts[i].name,search_name) == 0)
				{
					printf("Contact found \n");
					printf("Name:%s mobilenumber:%s email:%s", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        			found1 = 1;
                    break;

                }
           }

                if (!found1)
				{
                    printf("The Contact with name '%s' is not found.\n",search_name);
					break;
                }
				else
				{
				break;
				}
		
		
			case 2:
		char search_phone[20];
		printf("Enter the number to search :");
		scanf(" %[^\n]",search_phone);

		  for (int i = 0; i < addressBook->contactCount; i++) 
		  {
                if (strcmp(addressBook->contacts[i].phone,search_phone) == 0)
				{
					printf("Number found \n");
					printf("Name:%s mobilenumber:%s email:%s", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        			found2 = 1;
                    break;

                }
           }

                if (!found2)
				{
                    printf("The Contact with number '%s' is not found.\n",search_phone);
					break;
                }
				else
				{
				break;
				}
	 
			
			case 3:
			char search_email[20];
			printf("Enter the Email to search :");
			scanf(" %[^\n]",search_email);

		  for (int i = 0; i < addressBook->contactCount; i++) 
		  {
                if (strcmp(addressBook->contacts[i].email,search_email) == 0)
				{
					printf("Email found \n");
					printf("Name:%s mobilenumber:%s email:%s", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        			found3 = 1;
                    break;

                }
           }

                if (!found3)
				{
                    printf("The Contact with Email '%s' is not found.\n",search_email);
					break;
                }
				else
				{
				break;
				}
		
		case 4:
		return ;
		default:
		printf("---Invalid choice.please try again---\n");
		break;
	 
	 }
	 
}

	 


void editContact(AddressBook *addressBook)
{
	/* Define the logic for Editcontact */
	int choice;
	printf("select the details to edit\n1.name\n2.mobile_number\n3.email\n4.Exit \n ");
	printf("Enter the choice :");
	scanf("%d",&choice);
	int flag=0;

	switch(choice)
	{
	case 1:
    while(flag == 0)
	{	char search_name[20];
		int index;
		printf("Enter the name to edit: ");
		scanf(" %[^\n]", search_name);
		for (int i = 0; i < addressBook->contactCount; i++)
		{
			if (strcmp(search_name,addressBook->contacts[i].name) == 0)
			{
				flag = 1;
				index=i;
				break;
			}
			
		}

		if (flag == 1)
		{
			char new_name[20];
			printf("Enter the new name: ");
			scanf(" %[^\n]", new_name);
			while(name_validate(new_name) == 1)
			{
				printf("INFO: Name validation not done, Please enter valid name...\n");
				printf("Enter the new name: ");
				scanf(" %[^\n]", new_name);
				
			}
			while (unique_name(new_name,addressBook) == 1)
			{
				printf("INFO: Name already exists, Please enter valid name...\n");
				printf("Enter the new name: ");
				scanf(" %[^\n]", new_name);
				
			}
			strcpy(addressBook->contacts[index].name,new_name);
		 	printf("... contact edited successfully ...\n");
		}
	   else
	    {
			printf("....name you entered is not present....\n");
		}
	}

	case 2:
    while(flag == 0)
	{	char search_phone[20];
		int index;
		printf("Enter the number to edit: ");
		scanf(" %[^\n]", search_phone);
		for (int i = 0; i < addressBook->contactCount; i++)
		{
			if (strcmp(search_phone,addressBook->contacts[i].name) == 0)
			{
				flag = 1;
				index=i;
				break;
			}
			
		}

		if (flag == 1)
		{
			char new_phone[20];
			printf("Enter the new phone number: ");
			scanf(" %[^\n]", new_phone);
			while(phone_validate(new_phone) == 1)
			{
				printf("INFO: phone Number validation not done, Please enter valid number...\n");
				printf("Enter the new number: ");
				scanf(" %[^\n]", new_phone);
				
			}
			while (unique_phone(new_phone,addressBook) == 1)
			{
				printf("INFO: Name already exists, Please enter valid name...\n");
				printf("Enter the new number: ");
				scanf(" %[^\n]", new_phone);
				
			}
			strcpy(addressBook->contacts[index].phone,new_phone);
		 	printf("... contact edited successfully ...\n");
		}
	
	   else
	    {
			printf("....mobile_number you entered is not present....\n");
		}
	}

	case 3:
    while(flag == 0)
	{	char search_email[20];
		int index;
		printf("Enter the email to edit: ");
		scanf(" %[^\n]", search_email);
		for (int i = 0; i < addressBook->contactCount; i++)
		{
			if (strcmp(search_email,addressBook->contacts[i].email) == 0)
			{
				flag = 1;
				index=i;
				break;
			}
			
		}

		if (flag == 1)
		{
			char new_email[20];
			printf("Enter the new email: ");
			scanf(" %[^\n]", new_email);
			while(email_validate(new_email) == 1)
			{
				printf("INFO: email validation not done, Please enter valid email...\n");
				printf("Enter the new email: ");
				scanf(" %[^\n]", new_email);
				
			}
			while (unique_email(new_email,addressBook) == 1)
			{
				printf("INFO: email already exists, Please enter valid email...\n");
				printf("Enter the new email: ");
				scanf(" %[^\n]", new_email);
				
			}
			strcpy(addressBook->contacts[index].email,new_email);
		 	printf("... contact edited successfully ...\n");
		}
	   else
	    {
			printf("....email you entered is not present....\n");
		}
	}
	
	case 4:
	return ;
	default:
	printf("---Invalid choice.please try again---\n");
	break;
	}
}


void deleteContact(AddressBook *addressBook)
{
	
	int choice;
	int flag=0;
	printf("Enter the choice to delete\n1.name\n2.contact\n3.email\n4.Exit\n");
	printf("Enter the choice :");
	scanf("%d",&choice);

	switch(choice)
	{
		case 1:
		char delete_name[50];
		label1:
		printf("Enter the name to be deleted : ");
		scanf(" %[^\n]",delete_name);
		for(int i=0;i<addressBook->contactCount;i++)
		{
			if(strcmp(delete_name,addressBook->contacts[i].name)==0)

			{
				flag=1;
				for(int j=i;j<addressBook->contactCount-1;j++)
				{
					addressBook->contacts[j]=addressBook->contacts[j+1];
				}
				addressBook->contactCount--;
				printf(".....Contact sucessfully deleted......");
				printf("\n");
				break;
			}
			
		}

		if(flag==0)
		{
			printf("Enter correct name to be delete\n");
			goto label1;
		}
		break;

		case 2:
		char delete_contact[50];
		label2:
		printf("Enter the contact to be deleted : ");
		scanf(" %[^\n]",delete_contact);
		for(int i=0;i<addressBook->contactCount;i++)
		{
			if(strcmp(delete_contact,addressBook->contacts[i].phone)==0)

			{
				flag=1;
				for(int j=i;j<addressBook->contactCount-1;j++)
				{
					addressBook->contacts[j]=addressBook->contacts[j+1];
				}
				addressBook->contactCount--;
				printf(".....Contact sucessfully deleted......");
				printf("\n");
				break;
			}
			flag=0;
		}

		if(flag==0)
		{
			printf("Enter correct contact to be delete\n");
			goto label2;
		}
		break;

    case 3:
		char delete_email[50];
		label3:
		printf("Enter the email to be deleted : ");
		scanf(" %[^\n]",delete_email);
		for(int i=0;i<addressBook->contactCount;i++)
		{
			if(strcmp(delete_email,addressBook->contacts[i].email)==0)

			{
				flag=1;
				for(int j=i;j<addressBook->contactCount-1;j++)
				{
					addressBook->contacts[j]=addressBook->contacts[j+1];
				}
				addressBook->contactCount--;
				printf(".....Contact sucessfully deleted......");
				printf("\n");
				break;
			}
			flag=0;
		}

		if(flag==0)
		{
			printf("Enter correct contact to be delete\n");
			goto label3;
		}
		break;

		case 4:
		return ;
		default:
		printf("---Invalid choice.please try again---\n");
		break;
		
	}
  }

//////DELETE CONTACT////////
void listContacts(AddressBook *addressBook) 
{
	// Sort contacts based on the chosen criteria
	
    // Sort contacts based on the name (simple bubble sort)

    printf("Contacts List:\n");

    for (int i = 0; i < addressBook->contactCount; i++) 
	{
        printf("%s %s %s\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
}


