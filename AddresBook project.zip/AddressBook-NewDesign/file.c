#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) {
    FILE *ptr=fopen("contact.csv","w");
    if(ptr==NULL)
  {
    printf("File doesn't exist\n");
    return ;
  }
  fprintf(ptr,"#%d#\n",addressBook->contactCount);

  for(int i=0;i<addressBook->contactCount;i++)
  {
    fprintf(ptr,"%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
  }

   fclose(ptr);
   printf("Contacts saved succesfully....\n");
 }


void loadContactsFromFile(AddressBook *addressBook) {
  
    
    FILE *ptr;
    ptr=fopen("contact.csv","r");
    if(ptr==NULL)
    {
        printf("File doesn't exist");
        return ;
    }
    fscanf(ptr,"#%d#\n",&addressBook->contactCount);
    for(int i=0;i<addressBook->contactCount;i++)
    {
    fscanf(ptr,"%[^,],%[^,],%[^\n]\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    fclose(ptr);

}


